import './binance';
import './bot';
import './store';
